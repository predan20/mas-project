package mas.onto;

import jade.content.Concept;

public class TournamentEnd implements Concept {

}
