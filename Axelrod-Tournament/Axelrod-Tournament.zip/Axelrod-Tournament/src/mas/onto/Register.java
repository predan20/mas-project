package mas.onto;

import jade.content.Concept;

/**
 * Concept representing the REGISTER action send as a request by each player
 * participating in the tournament.
 */
public class Register implements Concept {

}
